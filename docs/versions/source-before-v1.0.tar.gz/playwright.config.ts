import { defineConfig } from '@playwright/test';
export default defineConfig({
  testDir: './tests',
  use: { baseURL: 'http://localhost:3000', channel: 'chrome' },
  webServer: { command: 'npm run start', url: 'http://localhost:3000', reuseExistingServer: true },
});
