import { Text } from '@/components/language-provider';
import type { Metadata } from 'next';
import { InquiryForm } from '@/components/inquiry-form';
export const metadata: Metadata = { title: 'Start a project', description: 'Bring your idea to Emilio Sierra’s independent creative technology studio.' };
export default function StartProject() {
  return <main id="main" className="inquiry-page page-shell"><div className="inquiry-heading"><p className="eyebrow"><Text text="Project inquiry / 001" /></p><h1><Text text="WHAT ARE" /><br /><Text text="WE MAKING" /><span className="cobalt">?</span></h1><p><Text text="Tell me a little about your project." /></p><p className="draft-note"><Text text="The inquiry experience is in preview while email delivery is being set up." /></p></div><InquiryForm /></main>;
}
