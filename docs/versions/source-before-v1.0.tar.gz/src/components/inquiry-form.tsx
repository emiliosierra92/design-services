'use client';
import { Text, useLanguage } from '@/components/language-provider';
import { useState } from 'react';
import { services } from '@/content/studio';
export function InquiryForm() {
  const { t } = useLanguage();
  const [reviewed, setReviewed] = useState(false);
  return <form className="inquiry-form" onSubmit={e => { e.preventDefault(); setReviewed(true); }}>
    <div className="form-notice" id="form-notice"><span className="eyebrow"><Text text="Inquiry preview" /></span><p><Text text="Email delivery is not connected yet. This form is for reviewing the inquiry experience; nothing will be sent or saved." /></p></div>
    <div className="form-grid"><label><Text text="Your name" /> <span><Text text="(required)" /></span><input autoComplete="name" name="name" required maxLength={120} /></label><label><Text text="Email address" /> <span><Text text="(required)" /></span><input type="email" autoComplete="email" name="email" required maxLength={254} /></label></div>
    <label><Text text="Company / organization" /> <span><Text text="(optional)" /></span><input autoComplete="organization" name="organization" maxLength={180} /></label>
    <fieldset><legend><Text text="What are you interested in?" /> <span><Text text="(choose any)" /></span></legend>{[...services.map(s => s.title), 'Something Else'].map(s => <label className="checkbox-label" key={s}><input type="checkbox" name="services" value={s} />{t(s)}</label>)}</fieldset>
    <label><Text text="Tell me about your project" /> <span><Text text="(required)" /></span><textarea name="message" required rows={5} maxLength={5000} placeholder={t("What are you trying to create, improve, or solve?")} /></label>
    <label><Text text="When are you hoping to get started?" /> <span><Text text="(optional)" /></span><input name="timeline" maxLength={180} /></label>
    <button className="text-link" type="submit" aria-describedby="form-notice"><Text text="Review inquiry preview" /> <span>→</span></button>
    <p role="status" className="form-status">{reviewed ? t('Preview reviewed. Your inquiry has not been sent. Email delivery must be configured before this form can accept inquiries.') : ''}</p>
  </form>;
}
