-- Store v1: sandbox-only foundation. No seed products or payment flow.
CREATE SCHEMA IF NOT EXISTS commerce;

CREATE FUNCTION commerce.touch_updated_at() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = clock_timestamp();
  RETURN NEW;
END;
$$;

CREATE TABLE commerce.products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE CHECK (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  name text NOT NULL CHECK (length(btrim(name)) BETWEEN 1 AND 200),
  description text NOT NULL DEFAULT '',
  price_in_cents integer NOT NULL CHECK (price_in_cents >= 0),
  currency text NOT NULL DEFAULT 'usd' CHECK (currency ~ '^[a-z]{3}$'),
  category text NOT NULL CHECK (length(btrim(category)) > 0),
  condition text NOT NULL CHECK (length(btrim(condition)) > 0),
  product_type text NOT NULL CHECK (product_type IN ('PHYSICAL', 'DIGITAL')),
  inventory_quantity integer NOT NULL DEFAULT 0 CHECK (inventory_quantity >= 0),
  status text NOT NULL DEFAULT 'DRAFT' CHECK (status IN ('DRAFT', 'ACTIVE', 'ARCHIVED')),
  weight_in_grams integer CHECK (weight_in_grams > 0),
  shipping_data jsonb CHECK (jsonb_typeof(shipping_data) = 'object'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (product_type = 'PHYSICAL' OR (weight_in_grams IS NULL AND shipping_data IS NULL))
);

CREATE TABLE commerce.product_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES commerce.products(id) ON DELETE CASCADE,
  image_reference text NOT NULL CHECK (
    image_reference ~ '^/[^/]' OR image_reference ~ '^https://[^[:space:]]+$'
  ),
  alt_text text NOT NULL DEFAULT '',
  sort_order integer NOT NULL DEFAULT 0 CHECK (sort_order >= 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (product_id, sort_order)
);

CREATE TABLE commerce.orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  checkout_request_id uuid NOT NULL UNIQUE,
  stripe_checkout_session_id text UNIQUE,
  stripe_payment_intent_id text UNIQUE,
  stripe_mode text NOT NULL DEFAULT 'TEST' CHECK (stripe_mode = 'TEST'),
  payment_status text NOT NULL DEFAULT 'PENDING'
    CHECK (payment_status IN ('PENDING', 'PAID', 'FAILED', 'EXPIRED', 'REFUNDED')),
  fulfillment_status text NOT NULL DEFAULT 'UNFULFILLED'
    CHECK (fulfillment_status IN ('UNFULFILLED', 'PROCESSING', 'FULFILLED', 'CANCELED')),
  customer_email text,
  subtotal_in_cents integer NOT NULL CHECK (subtotal_in_cents >= 0),
  shipping_amount_in_cents integer NOT NULL DEFAULT 0 CHECK (shipping_amount_in_cents >= 0),
  total_in_cents integer NOT NULL CHECK (total_in_cents >= 0),
  currency text NOT NULL CHECK (currency ~ '^[a-z]{3}$'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  -- Phase v1 has no discounts/taxes yet; add explicit fields before supporting them.
  CHECK (total_in_cents::bigint = subtotal_in_cents::bigint + shipping_amount_in_cents::bigint)
);

CREATE TABLE commerce.order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES commerce.orders(id) ON DELETE RESTRICT,
  product_id uuid NOT NULL REFERENCES commerce.products(id) ON DELETE RESTRICT,
  product_name_at_purchase text NOT NULL CHECK (length(btrim(product_name_at_purchase)) > 0),
  product_type_at_purchase text NOT NULL CHECK (product_type_at_purchase IN ('PHYSICAL', 'DIGITAL')),
  unit_price_in_cents integer NOT NULL CHECK (unit_price_in_cents >= 0),
  quantity integer NOT NULL CHECK (quantity > 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (order_id, product_id),
  UNIQUE (order_id, product_id, quantity)
);

CREATE TABLE commerce.inventory_reservations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL,
  product_id uuid NOT NULL,
  quantity integer NOT NULL CHECK (quantity > 0),
  status text NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'RELEASED', 'CONSUMED')),
  expires_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (order_id, product_id),
  FOREIGN KEY (order_id, product_id, quantity) REFERENCES commerce.order_items(order_id, product_id, quantity) ON DELETE RESTRICT,
  CHECK (expires_at > created_at)
);
-- Expired timestamps still count as ACTIVE until safely reconciled against Stripe.
CREATE INDEX reservations_active_product ON commerce.inventory_reservations(product_id) WHERE status = 'ACTIVE';
CREATE INDEX reservations_active_expiry ON commerce.inventory_reservations(expires_at) WHERE status = 'ACTIVE';

CREATE TABLE commerce.stripe_events (
  stripe_event_id text PRIMARY KEY,
  event_type text NOT NULL,
  stripe_mode text NOT NULL DEFAULT 'TEST' CHECK (stripe_mode = 'TEST'),
  order_id uuid REFERENCES commerce.orders(id) ON DELETE RESTRICT,
  processed_at timestamptz NOT NULL DEFAULT now()
);
-- Insert event IDs only in the transaction that commits payment/inventory changes.

CREATE TRIGGER products_updated_at BEFORE UPDATE ON commerce.products
FOR EACH ROW EXECUTE FUNCTION commerce.touch_updated_at();
CREATE TRIGGER orders_updated_at BEFORE UPDATE ON commerce.orders
FOR EACH ROW EXECUTE FUNCTION commerce.touch_updated_at();
CREATE TRIGGER reservations_updated_at BEFORE UPDATE ON commerce.inventory_reservations
FOR EACH ROW EXECUTE FUNCTION commerce.touch_updated_at();

CREATE INDEX order_items_product ON commerce.order_items(product_id);
CREATE INDEX orders_created_at ON commerce.orders(created_at);
CREATE INDEX stripe_events_order ON commerce.stripe_events(order_id);
