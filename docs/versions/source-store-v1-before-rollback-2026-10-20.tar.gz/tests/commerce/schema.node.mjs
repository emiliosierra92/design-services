import { test } from 'node:test';
import assert from 'node:assert/strict';
import { PGlite } from '@electric-sql/pglite';
import { loadMigrations, applyMigrations } from '../../scripts/commerce-migration-core.mjs';

const migrations = await loadMigrations(new URL('../../db/migrations/', import.meta.url));
function adapter(db) { return { query: (sql, values) => db.query(sql, values), execute: sql => db.exec(sql) }; }
async function withDatabase(fn) {
  const db = new PGlite();
  try { await fn(db); } finally { await db.close(); }
}
async function product(db, extra = {}) {
  const values = { slug: 'test-console', name: 'Test console', price: 15000, type: 'PHYSICAL', stock: 1, ...extra };
  return (await db.query(`INSERT INTO commerce.products
    (slug, name, price_in_cents, category, condition, product_type, inventory_quantity, status)
    VALUES ($1, $2, $3, 'console', 'pre-owned', $4, $5, 'ACTIVE') RETURNING *`, [values.slug, values.name, values.price, values.type, values.stock])).rows[0];
}
async function order(db, total = 15000) {
  return (await db.query(`INSERT INTO commerce.orders
    (checkout_request_id, subtotal_in_cents, total_in_cents, currency)
    VALUES (gen_random_uuid(), $1, $1, 'usd') RETURNING *`, [total])).rows[0];
}

test('migration runs on PostgreSQL, reruns safely, and rejects edited history', async () => withDatabase(async db => {
  assert.equal((await applyMigrations(adapter(db), migrations)).length, 1);
  assert.deepEqual(await applyMigrations(adapter(db), migrations), []);
  await assert.rejects(() => applyMigrations(adapter(db), [{ ...migrations[0], checksum: 'edited' }]), /history mismatch/);
  assert.equal((await db.query('SELECT count(*)::integer AS n FROM commerce.schema_migrations')).rows[0].n, 1);
}));
test('failed migration rolls back its DDL and migration history', async () => withDatabase(async db => {
  await applyMigrations(adapter(db), migrations);
  await assert.rejects(() => applyMigrations(adapter(db), [...migrations, { version: '0002_failure.sql', checksum: 'fixture', sql: 'CREATE TABLE commerce.should_rollback (id int); SELECT invalid_column;' }]));
  assert.equal((await db.query("SELECT to_regclass('commerce.should_rollback') AS table_name")).rows[0].table_name, null);
  assert.equal((await db.query('SELECT count(*)::integer AS n FROM commerce.schema_migrations')).rows[0].n, 1);
}));
test('schema enforces money, stock, type, image order and sandbox-only records', async () => withDatabase(async db => {
  await applyMigrations(adapter(db), migrations);
  const p = await product(db);
  assert.equal(p.inventory_quantity, 1);
  for (const extra of [{ slug: 'negative-price', price: -1 }, { slug: 'negative-stock', stock: -1 }, { slug: 'bad-type', type: 'UNKNOWN' }]) await assert.rejects(() => product(db, extra));
  const digital = await product(db, { slug: 'digital-fixture', type: 'DIGITAL', stock: 10 });
  await assert.rejects(() => db.query('UPDATE commerce.products SET weight_in_grams = 100 WHERE id = $1', [digital.id]));
  await db.query("INSERT INTO commerce.product_images (product_id, image_reference, sort_order) VALUES ($1, '/images/fixture.png', 0), ($1, '/images/fixture-back.png', 1)", [p.id]);
  await assert.rejects(() => db.query("INSERT INTO commerce.product_images (product_id, image_reference, sort_order) VALUES ($1, 'javascript:fixture', 2)", [p.id]));
  await assert.rejects(() => db.query("INSERT INTO commerce.product_images (product_id, image_reference, sort_order) VALUES ($1, '/images/fixture.png', 1)", [p.id]));
  const o = await order(db);
  await assert.rejects(() => db.query("UPDATE commerce.orders SET stripe_mode = 'LIVE' WHERE id = $1", [o.id]));
  await assert.rejects(() => db.query('UPDATE commerce.orders SET total_in_cents = 1 WHERE id = $1', [o.id]));
}));
test('purchase snapshots survive catalog edits and deletion is restricted', async () => withDatabase(async db => {
  await applyMigrations(adapter(db), migrations);
  const p = await product(db), o = await order(db);
  await db.query(`INSERT INTO commerce.order_items
    (order_id, product_id, product_name_at_purchase, product_type_at_purchase, unit_price_in_cents, quantity)
    VALUES ($1, $2, $3, $4, $5, 1)`, [o.id, p.id, p.name, p.product_type, p.price_in_cents]);
  await db.query("UPDATE commerce.products SET name = 'Changed', price_in_cents = 100 WHERE id = $1", [p.id]);
  const snapshot = (await db.query('SELECT * FROM commerce.order_items WHERE order_id = $1', [o.id])).rows[0];
  assert.equal(snapshot.product_name_at_purchase, 'Test console');
  assert.equal(snapshot.unit_price_in_cents, 15000);
  await assert.rejects(() => db.query('DELETE FROM commerce.products WHERE id = $1', [p.id]));
  await assert.rejects(() => db.query('UPDATE commerce.order_items SET quantity = 0 WHERE order_id = $1', [o.id]));
}));
test('reservation references purchased items and processed Stripe event IDs are unique', async () => withDatabase(async db => {
  await applyMigrations(adapter(db), migrations);
  const p = await product(db), o = await order(db);
  const reserve = () => db.query("INSERT INTO commerce.inventory_reservations (order_id, product_id, quantity, expires_at) VALUES ($1, $2, 1, now() + interval '30 minutes')", [o.id, p.id]);
  await assert.rejects(reserve);
  await db.query("INSERT INTO commerce.order_items (order_id, product_id, product_name_at_purchase, product_type_at_purchase, unit_price_in_cents, quantity) VALUES ($1, $2, 'Test console', 'PHYSICAL', 15000, 1)", [o.id, p.id]);
  await assert.rejects(() => db.query("INSERT INTO commerce.inventory_reservations (order_id, product_id, quantity, expires_at) VALUES ($1, $2, 2, now() + interval '30 minutes')", [o.id, p.id]));
  await reserve();
  await assert.rejects(reserve);
  const recordEvent = () => db.query("INSERT INTO commerce.stripe_events (stripe_event_id, event_type, order_id) VALUES ('evt_unit_fixture', 'checkout.session.completed', $1)", [o.id]);
  await recordEvent();
  await assert.rejects(recordEvent);
  assert.equal((await db.query('SELECT inventory_quantity FROM commerce.products WHERE id = $1', [p.id])).rows[0].inventory_quantity, 1);
  assert.equal((await db.query('SELECT payment_status FROM commerce.orders WHERE id = $1', [o.id])).rows[0].payment_status, 'PENDING');
}));
