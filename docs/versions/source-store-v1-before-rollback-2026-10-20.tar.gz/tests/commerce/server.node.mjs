import { test, afterEach } from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import Stripe from 'stripe';
import { integrationVariables, readServerVariable, requireTestStripeKey, requireDatabaseUrl } from '../../src/lib/commerce/environment.mjs';
import { getStripeTestClient } from '../../src/lib/commerce/stripe.mjs';
import { getCommerceSql } from '../../src/lib/commerce/database.mjs';
import { readCartProducts } from '../../src/lib/commerce/catalog.mjs';
import { validateCart, parseCartRequest } from '../../src/lib/commerce/cart.mjs';
import { prepareStripeWebhook } from '../../src/lib/commerce/webhook.mjs';

const originalBindings = { ...integrationVariables };
const originalFetch = globalThis.fetch;
const temporaryVariables = ['UNIT_STRIPE_KEY', 'UNIT_DATABASE_URL', 'UNIT_WEBHOOK_KEY'];
const originalEnvironment = Object.fromEntries(temporaryVariables.map(name => [name, process.env[name]]));
const id = 'ee8bc076-44d0-44ce-83c2-e21120fb2304';
const item = { productId: id, quantity: 1 };
afterEach(() => {
  Object.assign(integrationVariables, originalBindings);
  globalThis.fetch = originalFetch;
  for (const name of temporaryVariables) {
    if (originalEnvironment[name] === undefined) delete process.env[name];
    else process.env[name] = originalEnvironment[name];
  }
});

function configureStripe() {
  integrationVariables.stripeSecretKey = 'UNIT_STRIPE_KEY';
  integrationVariables.stripeWebhookSecret = 'UNIT_WEBHOOK_KEY';
  // Synthetic fixtures, not provider-issued keys. No API requests in these tests.
  process.env.UNIT_STRIPE_KEY = ['sk', 'test', 'fixture'].join('_');
  process.env.UNIT_WEBHOOK_KEY = 'whsec_unit_fixture';
}
function signedRequest({ livemode = false, tamper = false, stale = false } = {}) {
  const payload = JSON.stringify({ id: 'evt_unit_fixture', object: 'event', type: 'checkout.session.completed', livemode, data: { object: { id: 'cs_test_fixture', payment_status: 'paid' } } });
  const signature = Stripe.webhooks.generateTestHeaderString({ payload, secret: process.env.UNIT_WEBHOOK_KEY, ...(stale ? { timestamp: 1 } : {}) });
  return new Request('https://example.com/api/stripe/webhook', { method: 'POST', headers: { 'stripe-signature': signature }, body: tamper ? payload + ' ' : payload });
}

test('server modules reject ordinary client/runtime imports', () => {
  for (const moduleName of ['environment', 'stripe', 'database', 'catalog', 'webhook']) {
    const result = spawnSync(process.execPath, ['--input-type=module', '-e', `import './src/lib/commerce/${moduleName}.mjs'`], { cwd: process.cwd(), env: { ...process.env, NODE_OPTIONS: '' }, encoding: 'utf8' });
    assert.notEqual(result.status, 0);
    assert.match(result.stderr, /cannot be imported from a Client Component/);
  }
});
test('configuration fails closed for absent bindings and public or missing variables', () => {
  integrationVariables.stripeSecretKey = null;
  integrationVariables.databaseUrl = null;
  for (const name of [null, 'NEXT_PUBLIC_STRIPE_SECRET', 'missing-name', 'MISSING']) assert.throws(() => readServerVariable(name, {}), /configuration is unavailable/);
  assert.throws(() => readServerVariable('KEY', { KEY: ' private ' }), /configuration is unavailable/);
  assert.throws(() => getStripeTestClient(), /configuration is unavailable/);
  assert.throws(() => getCommerceSql(), /configuration is unavailable/);
});
test('Stripe rejects live, publishable, malformed and absent keys without revealing values', () => {
  for (const value of ['', 'sk_live_fixture', 'rk_live_fixture', 'pk_test_fixture', 'sk_test_', 'unknown']) {
    assert.throws(() => requireTestStripeKey(value), { message: 'Commerce configuration is unavailable.' });
  }
  assert.equal(requireTestStripeKey('rk_test_fixture'), 'rk_test_fixture');
  configureStripe();
  globalThis.fetch = () => { throw new Error('Unexpected provider request'); };
  assert.ok(getStripeTestClient());
  process.env.UNIT_STRIPE_KEY = 'sk_live_fixture';
  assert.throws(() => getStripeTestClient(), /configuration is unavailable/);
});
test('Neon rejects public, malformed, non-Neon and unencrypted connection strings', () => {
  for (const value of ['invalid', 'https://example.com', 'postgres://user:fixture@localhost/test', 'postgres://user:fixture@unit.neon.tech/test', 'postgres://user@unit.neon.tech/test?sslmode=require']) {
    assert.throws(() => requireDatabaseUrl(value), { message: 'Commerce configuration is unavailable.' });
  }
});
test('multi-item cart accepts IDs/quantities only and rejects price injection and duplicates', () => {
  const second = { productId: '6aca3a3f-d574-47d4-a7b7-2b88069f1e27', quantity: 2 };
  assert.deepEqual(validateCart({ items: [item, second] }), [item, second]);
  for (const input of [{ items: [] }, { items: [item], total: 1 }, { items: [{ ...item, price: 1 }] }, { items: [item, { ...item, productId: id.toUpperCase() }] }, { items: [{ ...item, quantity: 0 }] }, { items: [{ ...item, quantity: 1.5 }] }, { items: [{ ...item, quantity: 100 }] }, { items: [{ ...item, productId: "'; DROP TABLE products;--" }] }, { items: Array(51).fill(item) }]) assert.throws(() => validateCart(input), /Invalid cart/);
  assert.throws(() => parseCartRequest(' '.repeat(16385)), /Invalid cart/);
  assert.throws(() => parseCartRequest('{'), /Invalid cart/);
});
test('catalog uses bound UUID parameters and counts expired but unreconciled reservations', async () => {
  integrationVariables.databaseUrl = 'UNIT_DATABASE_URL';
  process.env.UNIT_DATABASE_URL = 'postgresql://unit:fixture@unit.neon.tech/test?sslmode=require';
  let captured;
  globalThis.fetch = async (_url, options) => {
    captured = JSON.parse(options.body);
    return Response.json({ fields: [], rows: [], command: 'SELECT', rowCount: 0 });
  };
  await readCartProducts({ items: [item] });
  assert.ok(captured.query.includes('$1::uuid[]'));
  assert.equal(captured.query.includes(id), false);
  assert.ok(captured.params.length === 1);
  assert.ok(JSON.stringify(captured.params).includes(id));
  assert.match(captured.query, /status = 'ACTIVE'/);
  assert.doesNotMatch(captured.query, /expires_at\s*[><]/);
});
test('unconfigured webhook cannot claim successful payment processing', async () => {
  const response = await prepareStripeWebhook(new Request('https://example.com', { method: 'POST', body: '{}' }));
  assert.equal(response.status, 503);
  assert.deepEqual(await response.json(), { error: 'Webhook processing is unavailable.' });
});
test('webhook verifies raw body, rejects tampered/stale/live events, and never acknowledges unprocessed payments', async () => {
  configureStripe();
  assert.equal((await prepareStripeWebhook(signedRequest({ tamper: true }))).status, 400);
  assert.equal((await prepareStripeWebhook(signedRequest({ stale: true }))).status, 400);
  assert.equal((await prepareStripeWebhook(signedRequest({ livemode: true }))).status, 400);
  for (let i = 0; i < 2; i++) assert.equal((await prepareStripeWebhook(signedRequest())).status, 503);
  assert.equal((await prepareStripeWebhook(new Request('https://example.com', { method: 'POST', body: '{}' }))).status, 400);
  const oversized = new Request('https://example.com', { method: 'POST', headers: { 'stripe-signature': 'fixture' }, body: 'x'.repeat(262145) });
  assert.equal((await prepareStripeWebhook(oversized)).status, 413);
});
