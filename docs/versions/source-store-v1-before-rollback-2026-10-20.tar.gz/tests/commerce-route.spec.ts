import { test, expect } from '@playwright/test';

test('prepared Stripe webhook stays unavailable and never acknowledges payment', async ({ request }) => {
  const response = await request.post('/api/stripe/webhook', {
    data: { type: 'checkout.session.completed', livemode: false },
  });
  expect(response.status()).toBe(503);
  expect(await response.json()).toEqual({ error: 'Webhook processing is unavailable.' });
  expect(response.headers()['cache-control']).toBe('no-store');
  expect((await request.get('/api/stripe/webhook')).status()).toBe(405);
});
