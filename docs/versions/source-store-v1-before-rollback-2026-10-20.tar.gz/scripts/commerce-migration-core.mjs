// @ts-check
import { readdir, readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';

/** @typedef {{version: string, sql: string, checksum: string}} Migration */
/** @typedef {{query: (sql: string, parameters?: unknown[]) => Promise<{rows: Record<string, unknown>[]}> , execute: (sql: string) => Promise<unknown>}} MigrationDatabase */

/** @param {string | URL} directory @returns {Promise<Migration[]>} */
export async function loadMigrations(directory) {
  const names = (await readdir(directory)).filter(name => /^\d{4}_[a-z0-9_]+\.sql$/.test(name)).sort();
  const versions = new Set();
  return Promise.all(names.map(async version => {
    const prefix = version.slice(0, 4);
    if (versions.has(prefix)) throw new Error('Duplicate migration version.');
    versions.add(prefix);
    const sql = await readFile(typeof directory === 'string' ? pathToFileURL(resolve(directory, version)) : new URL(version, directory), 'utf8');
    return { version, sql, checksum: createHash('sha256').update(sql).digest('hex') };
  }));
}

/** @param {MigrationDatabase} db @param {Migration[]} migrations */
export async function applyMigrations(db, migrations) {
  await db.query('BEGIN');
  try {
    // Serialize runners across Vercel instances/processes, not just this process.
    await db.query('SELECT pg_advisory_xact_lock($1)', [731420190]);
    await db.execute(`CREATE SCHEMA IF NOT EXISTS commerce;
      CREATE TABLE IF NOT EXISTS commerce.schema_migrations (
        version text PRIMARY KEY, checksum text NOT NULL, applied_at timestamptz NOT NULL DEFAULT now()
      );`);
    const { rows } = await db.query('SELECT version, checksum FROM commerce.schema_migrations ORDER BY version');
    const known = new Map(migrations.map(m => [m.version, m]));
    for (const row of rows) {
      if (known.get(String(row.version))?.checksum !== row.checksum) throw new Error('Migration history mismatch.');
    }
    const applied = new Set(rows.map(row => String(row.version)));
    const latest = rows.length ? String(rows[rows.length - 1].version) : '';
    const pending = migrations.filter(m => !applied.has(m.version));
    if (pending.some(m => m.version < latest)) throw new Error('Migration history is out of order.');
    for (const migration of pending) {
      // Only trusted repository SQL files execute here; application input is never SQL text.
      await db.execute(migration.sql);
      await db.query('INSERT INTO commerce.schema_migrations (version, checksum) VALUES ($1, $2)', [migration.version, migration.checksum]);
    }
    await db.query('COMMIT');
    return pending.map(m => m.version);
  } catch (error) {
    await db.query('ROLLBACK').catch(() => {});
    throw error;
  }
}
