// @ts-check
import { loadMigrations, applyMigrations } from './commerce-migration-core.mjs';
import { createCommerceTransactionClient } from '../src/lib/commerce/database.mjs';

const args = process.argv.slice(2);
/** @type {ReturnType<typeof createCommerceTransactionClient> | undefined} */
let client;
try {
  if (args.some(arg => !['--apply', '--confirm-test-database'].includes(arg))) throw new Error();
  const migrations = await loadMigrations(new URL('../db/migrations/', import.meta.url));
  if (!args.includes('--apply')) {
    console.log('Repository migrations (not database status):');
    for (const migration of migrations) console.log(migration.version);
    console.log('No database connection made. Applying requires --apply --confirm-test-database.');
  } else {
    if (!args.includes('--confirm-test-database')) throw new Error();
    const connection = createCommerceTransactionClient();
    client = connection;
    await connection.connect();
    const applied = await applyMigrations({ query: (sql, values) => connection.query(sql, values), execute: sql => connection.query(sql) }, migrations);
    console.log(applied.length ? `Applied: ${applied.join(', ')}` : 'Database migrations are up to date.');
  }
} catch {
  // Provider errors may contain connection strings. Never print their details.
  console.error('Migration failed. Verify server configuration, confirmed test database, and migration history. No provider details displayed.');
  process.exitCode = 1;
} finally {
  if (client) await client.end().catch(() => {});
}
