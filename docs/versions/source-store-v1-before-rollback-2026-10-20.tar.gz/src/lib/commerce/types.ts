export type ProductType = 'PHYSICAL' | 'DIGITAL';
export type ProductStatus = 'DRAFT' | 'ACTIVE' | 'ARCHIVED';
export type PaymentStatus = 'PENDING' | 'PAID' | 'FAILED' | 'EXPIRED' | 'REFUNDED';
export type FulfillmentStatus = 'UNFULFILLED' | 'PROCESSING' | 'FULFILLED' | 'CANCELED';
export type ReservationStatus = 'ACTIVE' | 'RELEASED' | 'CONSUMED';
export interface CartItem { productId: string; quantity: number }
export interface Product {
  id: string;
  slug: string;
  name: string;
  description: string;
  price_in_cents: number;
  currency: string;
  category: string;
  condition: string;
  product_type: ProductType;
  inventory_quantity: number;
  status: ProductStatus;
  weight_in_grams: number | null;
  shipping_data: Record<string, unknown> | null;
  created_at: string;
  updated_at: string;
}
