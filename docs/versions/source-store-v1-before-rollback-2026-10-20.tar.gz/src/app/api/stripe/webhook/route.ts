import { prepareStripeWebhook } from '../../../../lib/commerce/webhook.mjs';

export const runtime = 'nodejs';
export async function POST(request: Request) {
  return prepareStripeWebhook(request);
}
