# Emilio Sierra — Creative Technology Studio

Website design prototype based on the owner’s Design System v1.0, with the original v0.8 brief preserved. Built with Next.js App Router, React, strict TypeScript and native CSS. Display typography uses locally bundled Cormorant Garamond (400/500); interface typography uses Verdana.

## Local development

Use Node.js 22.13+ or a newer supported LTS (one lint dependency requires 22.13+). The current Node 22.12 installation passes build, lint and type checks but reports that dependency engine warning.

```sh
npm ci
npm run dev
```

Visit http://localhost:3000.

```sh
npm run lint
npm run build
npm run typecheck
npm run test:e2e
```

## Structure

- `src/app/page.tsx`: five-section homepage.
- `src/app/work/[project]/page.tsx`: statically generated project stories.
- `src/app/start-a-project/page.tsx`: inquiry preview.
- `src/content/studio.ts`: three project stories and service content.
- `src/content/spanish.ts`: Spanish copy for the English/Spanish footer switch.
- `docs/design-system-v1.0.txt`: current owner-supplied design direction.
- `docs/version-history.md`: version notes and a link to the pre-v1.0 source snapshot.
- `src/components`: navigation, footer, inquiry preview and explicit media placeholders.
- `src/app/globals.css`: responsive compositions, semantic tokens and reduced-motion support.
- `docs/master-specification.txt`: original brief preserved verbatim, including every unresolved owner action.
- `docs/launch-checklist.md`: implementation boundaries and launch work.

## Current boundaries

This is a design prototype, not a production handoff. The supplied portraits, packaging artwork and broadcast collage are integrated. The website case study uses a code-native studio composition. Homepage narrative follows the v1.0 brief; service scope, project facts/credits and publication details still need launch review. The placeholder ES favicon also needs owner review.

The form only validates and reviews locally. It never sends or stores an inquiry, and makes no success claim. No email provider, credentials, destination address, analytics, cookies or third-party embeds are configured. No environment variables are required for this preview.

Robots metadata and `/robots.txt` prevent indexing by cooperative search engines while content is unapproved. This does not restrict access; use deployment access protection if sharing a preview privately. Sitemap, canonical/OG metadata and approved social imagery should be finalized as part of launch preparation.

## Deployment

The repository is compatible with a standard Vercel Next.js project. Nothing has been deployed. Complete the launch checklist before enabling public indexing or accepting inquiries.

Browser tests use installed Google Chrome, build into `.next-test`, and start an isolated production server on port 3100 so they do not reuse or overwrite the development server. They cover routes, automated accessibility, layout overflow, mobile menu focus and honest inquiry preview behavior.
