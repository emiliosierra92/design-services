import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
test('all routes render with no critical accessibility violations', async ({ page }) => {
  for (const path of ['/', '/work/emilio-sierra-studio', '/work/theatrical-prop-packaging', '/work/live-sports-broadcasting', '/start-a-project']) {
    const response = await page.goto(path);
    expect(response?.status()).toBe(200);
    await expect(page.locator('h1')).toBeVisible();
    const results = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21aa', 'wcag22aa']).analyze();
    expect(results.violations).toEqual([]);
  }
  expect((await page.goto('/work/missing-project'))?.status()).toBe(404);
});
test('layouts fit representative viewports', async ({ page }) => {
  test.setTimeout(60000);
  await page.emulateMedia({ reducedMotion: 'reduce' });
  for (const width of [360, 390, 768, 1024, 1440, 1920]) {
    await page.setViewportSize({ width, height: 900 });
    await page.goto('/');
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  }
  await page.setViewportSize({ width: 390, height: 844 });
  for (const image of await page.locator('main img').all()) {
    await image.scrollIntoViewIfNeeded();
    await image.evaluate((element: HTMLImageElement) => { element.loading = 'eager'; });
    await expect.poll(() => image.evaluate((element: HTMLImageElement) => element.complete && element.naturalWidth > 0), { timeout: 15000 }).toBe(true);
  }
  await page.evaluate(() => window.scrollTo({ top: 0, behavior: 'instant' }));
  await expect(page.locator('header')).not.toHaveClass(/night-nav/);
  await page.screenshot({ path: 'test-results/home-mobile.png', fullPage: true });
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.goto('/');
  for (const image of await page.locator('main img').all()) {
    await image.scrollIntoViewIfNeeded();
    await image.evaluate((element: HTMLImageElement) => { element.loading = 'eager'; });
    await expect.poll(() => image.evaluate((element: HTMLImageElement) => element.complete && element.naturalWidth > 0), { timeout: 15000 }).toBe(true);
  }
  await page.locator('.about-portrait').screenshot({ path: 'test-results/about-portrait-desktop.png' });
  await page.evaluate(() => window.scrollTo({ top: 0, behavior: 'instant' }));
  await expect(page.locator('header')).not.toHaveClass(/night-nav/);
  await page.screenshot({ path: 'test-results/home-desktop.png', fullPage: true });
  await page.screenshot({ path: 'test-results/storefront-desktop.png' });
});
test('mobile menu contains focus, closes on Escape, and restores focus', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto('/');
  const trigger = page.getByRole('button', { name: 'Menu', exact: true });
  await trigger.click();
  await expect(page.getByRole('dialog')).toBeVisible();
  for (let i = 0; i < 7; i++) {
    await page.keyboard.press('Tab');
    expect(await page.evaluate(() => !!document.activeElement?.closest('dialog'))).toBe(true);
  }
  await page.keyboard.press('Escape');
  await expect(page.getByRole('dialog')).not.toBeVisible();
  await expect(trigger).toBeFocused();
  await trigger.click();
  await page.getByRole('navigation', { name: 'Mobile navigation' }).getByRole('link', { name: /Services/ }).click();
  await expect(page.getByRole('dialog')).not.toBeVisible();
  await expect(page).toHaveURL(/#services$/);
});
test('inquiry preview makes no false delivery claim or submission', async ({ page }) => {
  await page.goto('/start-a-project');
  let posts = 0;
  page.on('request', request => { if (request.method() === 'POST') posts++; });
  await page.getByLabel('Your name').fill('Preview User');
  await page.getByLabel('Email address').fill('preview@example.com');
  await page.getByLabel('Graphic Design', { exact: true }).check();
  await page.getByLabel('Tell me about your project').fill('Testing the inquiry prototype.');
  await page.getByRole('button', { name: 'Review inquiry preview' }).click();
  await expect(page.getByRole('status')).toContainText('has not been sent');
  expect(posts).toBe(0);
});

test('v1.0 presents three project disciplines and supports reduced motion', async ({ page }) => {
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.goto('/');
  const projects = page.locator('#work article');
  await expect(projects).toHaveCount(3);
  for (const name of ['EmilioSierra.com', 'Vintage Packaging Recreated for the Stage', 'Behind the Live Broadcast']) {
    await expect(projects.getByRole('heading', { name, exact: true })).toBeVisible();
  }
  expect(await page.evaluate(() => getComputedStyle(document.documentElement).scrollBehavior)).toBe('auto');
  await page.locator('#about').scrollIntoViewIfNeeded();
  await expect(page.locator('header')).toHaveClass(/night-nav/);
  await page.getByRole('link', { name: 'Back to daylight' }).click();
  await expect(page).toHaveURL(/#storefront$/);
  await expect(page.locator('header')).not.toHaveClass(/night-nav/);
  await page.getByRole('button', { name: 'Español', exact: true }).click();
  await expect(page.getByRole('heading', { name: '¿QUÉ PUEDO CREAR PARA TI?' })).toBeVisible();
});
