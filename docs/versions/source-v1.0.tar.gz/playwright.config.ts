import { defineConfig } from '@playwright/test';
export default defineConfig({
  testDir: './tests',
  use: { baseURL: 'http://localhost:3100', channel: 'chrome' },
  webServer: { command: 'STUDIO_TEST_BUILD=1 npm run start -- --port 3100', url: 'http://localhost:3100', reuseExistingServer: false },
});
