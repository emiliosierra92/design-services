FAMILIAR UX. UNFAMILIAR PRESENTATION.

Use docs/design-system-v1.0.txt as the current design direction. Preserve docs/master-specification.txt and docs/versions/original-v0.8.txt as historical briefs. Where the new design brief supersedes the old design direction, v1.0 wins; existing factual content and unresolved launch requirements still apply.

Keep major version changes in docs/version-history.md. Preserve prior briefs when introducing a new one; never rewrite a historical prompt to match current implementation.

Use Cormorant Garamond for display statements and Verdana for information and interfaces. Respect the daylight-to-night progression, architectural shapes, 12/8/4 alignment grids, and functional use of red. Large things move slowly; small things respond quickly. Reduced motion, visible focus, semantic HTML, keyboard access and WCAG 2.2 AA are part of the design.

Keep the supplied portraits and project imagery, English/Spanish footer controls, and truthful inquiry-preview behavior. Do not invent project outcomes, credentials or live status. Do not deploy unless asked.
