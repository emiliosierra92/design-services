'use client';
import { Text, useLanguage } from '@/components/language-provider';
import Link from 'next/link';
import Image from 'next/image';
import daylightPortrait from '../../public/images/emilio-daylight-portrait.png';
import formalPortrait from '../../public/images/emilio-formal-portrait.png';
import { StudioPreview } from '@/components/studio-preview';
import { projects, services } from '@/content/studio';

export default function Home() {
  const { t } = useLanguage();
  return <main id="main">
    <section id="storefront" className="hero" data-environment="daylight" aria-labelledby="hero-title">
      <div className="hero-topline eyebrow"><span><Text text="01 / Storefront" /></span><span>MIAMI / FL</span></div>
      <div className="hero-grid">
        <div className="hero-copy">
          <p className="eyebrow"><Text text="Independent by design." /></p>
          <h1 id="hero-title"><Text text="I CREATE" /><br /><span><Text text="WHAT’S NEXT" /><span className="cobalt">.</span></span></h1>
          <div className="hero-intro"><p><Text text="I use design and technology to turn ideas and everyday problems into useful experiences—from websites and applications to graphic design and video." /></p><Link href="#work" className="text-link"><Text text="Explore my work" /> <span>→</span></Link></div>
        </div>
        <div className="hero-visual"><div className="hero-portrait"><Image src={daylightPortrait} alt={t('Emilio Sierra using his smartphone beside sunlit windows and tropical greenery.')} fill sizes="(max-width: 760px) 90vw, 50vw" preload placeholder="blur" /></div><p className="image-note eyebrow"><Text text="A human perspective. A forward-looking practice." /></p></div>
      </div>
      <div className="service-directory">{services.map(s => <a href={`#service-${s.number}`} key={s.number}><span>{s.number} /</span>{t(s.title)}<span>↘</span></a>)}</div>
    </section>

    <section id="work" className="work section-space" data-environment="afternoon" aria-labelledby="work-title">
      <div className="section-heading"><p className="eyebrow"><Text text="02 / Selected work" /></p><h2 id="work-title"><Text text="IDEAS," /><br /><Text text="MADE REAL." /></h2><span className="eyebrow"><Text text="Design / Production / Experience" /></span></div>
      {projects.map((p, i) => <article className={`project project-${i} project-${p.kind}`} key={p.slug}>
        <Link className="project-media-link" href={`/work/${p.slug}`} aria-label={`${t('Explore')} ${t(p.name)}`}>
          <div className="project-vocabulary eyebrow"><span>{t(p.vocabulary)}</span>{p.kind === 'broadcast' && <span className="broadcast-label"><i className="signal-dot" aria-hidden="true" /><Text text="Live broadcast" /></span>}</div>
          {p.image ? <Image className="project-image" src={p.image.src} alt={t(p.image.alt)} sizes="(max-width: 760px) 90vw, 65vw" placeholder="blur" /> : <StudioPreview />}
        </Link>
        <div className="project-info"><p className="eyebrow"><Text text="Project /" /> {p.number}<span>{t(p.discipline)}</span></p><Link href={`/work/${p.slug}`} className="project-title"><h3>{t(p.title)}</h3><span>↗</span></Link><p>{t(p.summary)}</p><Link href={`/work/${p.slug}`} className="text-link"><Text text="Explore the story" /> <span>→</span></Link></div>
      </article>)}
    </section>

    <section id="services" className="services section-space" data-environment="golden-hour" aria-labelledby="services-title">
      <div className="section-heading"><p className="eyebrow"><Text text="03 / What I do" /></p><h2 id="services-title"><Text text="WHAT CAN I" /><br /><Text text="CREATE FOR YOU?" /></h2></div>
      <div className="services-list">{services.map(s => <article id={`service-${s.number}`} className="service-row" key={s.number}><p className="eyebrow">{s.number} / {t(s.discipline)}</p><h3>{t(s.title)}</h3><div><p>{t(s.description)}</p><p className="eyebrow capabilities">{t(s.capabilities)}</p><Link href="/start-a-project" className="text-link"><Text text="Let’s talk" /> <span>↗</span></Link></div></article>)}</div>
    </section>

    <section id="about" className="about section-space" data-environment="blue-hour" aria-labelledby="about-title">
      <p className="eyebrow"><Text text="04 / Profile" /></p>
      <div className="about-grid"><h2 id="about-title"><Text text="CURIOSITY" /><br /><Text text="MADE ME" /><br /><Text text="A CREATOR" /><span>.</span></h2><div className="about-copy">
        <p className="large-copy"><Text text="I’ve always been creative, and technology has always come naturally to me. Curiosity connected the two." /></p>
        <p><Text text="Growing up, I found myself constantly reading, learning and exploring whatever captured my attention. The more I learned, the more questions I had—and eventually, those questions became things I wanted to create." /></p>
        <p><Text text="What excites me most is the possibility of building technology that can make someone’s everyday life a little better." /></p>
        <p className="display-copy"><Text text="Ultimately, I want to invent things." /></p>
        <div className="about-portrait"><Image className="about-portrait-image" src={formalPortrait} alt={t('Emilio Sierra standing indoors in a white shirt, light blue tie and beige trousers.')} sizes="(max-width: 760px) 90vw, 40vw" placeholder="blur" /></div>
        <p className="eyebrow"><Text text="Creator / Designer / Developer / Producer" /></p>
      </div></div>
    </section>

    <section id="contact" className="contact section-space" data-environment="night" aria-labelledby="contact-title">
      <p className="eyebrow"><Text text="05 / Start something" /></p>
      <h2 id="contact-title"><Text text="LET’S MAKE" /><br /><Text text="SOMETHING" /><span>.</span></h2>
      <div className="contact-bottom"><p><Text text="Have an idea, a problem to solve, or something you want to create? Tell me about it." /></p><Link href="/start-a-project" className="text-link"><Text text="Start a project" /> <span>→</span></Link></div>
      <a className="eyebrow daylight-link" href="#storefront"><Text text="Back to daylight ↑" /></a>
    </section>
  </main>;
}
