import { Text } from '@/components/language-provider';

/** A code-native composition of this site's actual identity, not a fabricated screenshot. */
export function StudioPreview() {
  return <div className="studio-preview">
    <div className="studio-preview-bar"><span>EMILIOSIERRA.COM</span><span>WEB + APP / 001</span></div>
    <div className="studio-preview-grid" aria-hidden="true" />
    <div className="studio-preview-copy"><p className="eyebrow"><Text text="Design meets technology" /></p><p className="studio-preview-title"><Text text="Ideas," /><br /><Text text="made real." /></p><span className="studio-preview-arrow" aria-hidden="true">↗</span></div>
    <div className="studio-preview-bottom"><span><Text text="A digital storefront" /></span><span>MIAMI / FL</span></div>
  </div>;
}
