'use client';
import Link from 'next/link';
import Image from 'next/image';
import { projects } from '@/content/studio';
import { StudioPreview } from '@/components/studio-preview';
import { Text, useLanguage } from '@/components/language-provider';

export function CaseStudyView({ index }: { index: number }) {
  const { t } = useLanguage();
  const entry = projects[index];
  const next = projects[(index + 1) % projects.length];
  return <main id="main" className={`case-study case-${entry.kind} page-shell`}>
    <Link className="text-link" href="/#work"><Text text="← All work" /></Link>
    <p className="eyebrow case-label"><Text text="Project /" /> {entry.number} — {t(entry.discipline)}</p>
    <h1>{t(entry.title)}</h1>
    <p className="large-copy">{t(entry.summary)}</p>
    <div className="project-vocabulary eyebrow"><span>{t(entry.vocabulary)}</span>{entry.kind === 'broadcast' && <span className="broadcast-label"><i className="signal-dot" aria-hidden="true" /><Text text="Live broadcast" /></span>}</div>
    {entry.image ? <Image className="project-image" src={entry.image.src} alt={t(entry.image.alt)} sizes="90vw" placeholder="blur" /> : <StudioPreview />}
    <div className="case-sections">{entry.sections.map((s, i) => <section key={s.title}><p className="eyebrow">0{i + 1} <Text text="/ The story" /></p><div><h2>{t(s.title)}</h2><p>{t(s.text)}</p></div></section>)}</div>
    <Link className="next-project" href={`/work/${next.slug}`}><span className="eyebrow"><Text text="Next project ↗" /></span><span>{t(next.name)}</span></Link>
  </main>;
}
